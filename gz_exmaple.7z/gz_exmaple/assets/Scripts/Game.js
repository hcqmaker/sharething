
cc.Class({
    extends: cc.Component,

    properties: {

    },

    start () {

        //=============================================
        // 普通的文件的话使用普通,gz结尾的用当前的处理方案
        var func =  function(item, callback) {
            // 根据不同情况进行判断处理否则问题多多
            var url = item.url;
            var errInfo = 'Load binary data failed: ' + url + '';
            var xhr = cc.loader.getXMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.responseType = "arraybuffer";
            xhr.onload = function () {
                var arrayBuffer = xhr.response;
                if (arrayBuffer) {
                    var result = new Uint8Array(arrayBuffer);
                    //===================================
                    let outString = "";
                    let uerr = null;
                    try {
                        outString = pako.inflate(result, { gzip: true, to: 'string'});
                    } catch (error) {
                        cc.log(error);
                        uerr = error;
                    }
                    //===================================
                    if (!uerr){
                        callback(null, outString);
                    }else{
                        callback({status:-1, err:uerr,errorMessage:errInfo + " pako.inflate fail "});
                    }
                }
                else {
                    callback({status:xhr.status, errorMessage:errInfo + '(no response)'});
                }
            };
            xhr.onerror = function(){
                callback({status:xhr.status, errorMessage:errInfo + '(error)'});
            };
            xhr.ontimeout = function(){
                callback({status:xhr.status, errorMessage:errInfo + '(time out)'});
            };
            xhr.send(null);
        }

        var extMap = cc.loader.loader.extMap;

        cc.loader.addDownloadHandlers({"gz":func});
        cc.loader.addLoadHandlers({"gz":extMap['prefab']});


        cc.loader.loadRes("prefabcompresss/node_01", (err, res)=>{
            if (err) {
                cc.error(err.message || err);
                return;
            }

            var prefab = null;
            if (res instanceof cc.Prefab){
                prefab = res;
            }else{
                if (res instanceof cc.Asset && res._native == '.gz'){
                    prefab = res._nativeAsset;
                }
            }


            var n = cc.instantiate(prefab);
            this.node.addChild(n);

        });
    },

    // update (dt) {},
});
