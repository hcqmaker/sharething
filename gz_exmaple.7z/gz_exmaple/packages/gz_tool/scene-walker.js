const path = require('path');
const fs = require('fs');
const zlib = require('zlib');

module.exports = {
    
	'ouput_deepQuery':function(){
		Editor.assetdb.deepQuery(function (err, results) {
		  results.forEach(function (result) {
			// result.name
			// result.extname
			// result.uuid
			// result.type
			// result.isSubAsset
			// result.children - the array of children result
			Editor.log('===>> xx==>',result.name,result.type);
		  });
		});
		/*
		Editor.assetdb.queryAssets('db://assets/**\/*', 'texture', function (err, results) {
			results.forEach(function (result) {
				// result.url
				// result.path
				// result.uuid
				// result.type
			});
		});
		*/
	},
	'say-gzfile':function(event){
		//ouput_deepQuery();
		
		var func = function(n){
			var str = n.replace('media', 'resources')
			var str = str.replace('prefabs', 'prefabcompresss')
			var str = str.replace('.prefab','.gz');
			return str;
		}
		
		Editor.assetdb.queryAssets('db://assets/media/prefabs/**\/*', 'prefab', function(err, results){
			results.forEach(function (result) {
				//Editor.log(result);
				
				var tpath = func(result.path);
				var upath = path.dirname(tpath);
				
				if (!fs.existsSync(upath)){
					fs.mkdirSync(upath);
				}
				
				const gzip = zlib.createGzip();
				const inp = fs.createReadStream(result.path);
				const out = fs.createWriteStream(tpath);

				inp.pipe(gzip).pipe(out);
				
			});
		});
		
		Editor.assetdb.refresh('db://assets/resources/prefabcompresss/', function (err, results) {});
		if (event.reply) {
            event.reply('OK');
        }
	},
};