'use strict';

module.exports = {
  load () {
    // execute when package loaded
  },

  unload () {
    // execute when package unloaded
  },

  // register your ipc messages here
  messages: {
    'open' () {
      // open entry panel registered in package.json
      Editor.Panel.open('gz_tool');
    },
    'say-hello' () {
      Editor.log('Hello World!');
      // send ipc message to panel
      //Editor.Ipc.sendToPanel('gz_tool', 'gz_tool:hello');
	  
	  
	  Editor.Scene.callSceneScript('gz_tool', 'say-gzfile', function (err, val) {
			Editor.log(`say-gzfile rep:${val}`);
		});
    },
    'clicked' () {

    }
  },
};