(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scripts/Game.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '7dd90GsempOVIfLtv9J/Ntp', 'Game', __filename);
// Scripts/Game.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    start: function start() {
        var _this = this;

        cc.loader.loadRes("prefabs/node_01", function (err, prefab) {
            if (err) {
                cc.error(err.message || err);
                return;
            }

            var n = cc.instantiate(prefab);
            _this.node.addChild(n);
        });
    }
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Game.js.map
        