(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scripts/utils/utils.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a4e00+/aXVDe6/Kgq1OBUEh', 'utils', __filename);
// Scripts/utils/utils.js

"use strict";

var Uint8ArrayToString = function Uint8ArrayToString(buf) {
    return String.fromCharCode.apply(null, buf);
};

//=============================================
var funcJson = function funcJson(item, callback) {
    // 根据不同情况进行判断处理否则问题多多
    var url = item.url;
    var errInfo = 'Load binary data failed: ' + url + '';
    var xhr = cc.loader.getXMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = "arraybuffer";
    xhr.onload = function () {
        var arrayBuffer = xhr.response;
        if (arrayBuffer) {
            var result = new Uint8Array(arrayBuffer);

            var outString = "";
            var uerr = null;
            //===================================
            // 判断开头的处理 是否是压缩方式
            if (result[0] == 0x1f && result[1] == 0x8b) {
                try {
                    outString = pako.inflate(result, { gzip: true, to: 'string' });
                } catch (error) {
                    cc.log(error);
                    uerr = error;
                }
            } else {
                outString = Uint8ArrayToString(result);
            }
            //===================================
            if (!uerr) {
                callback(null, outString);
            } else {
                callback({ status: -1, err: uerr, errorMessage: errInfo + " pako.inflate fail " });
            }
        } else {
            callback({ status: xhr.status, errorMessage: errInfo + '(no response)' });
        }
    };
    xhr.onerror = function () {
        callback({ status: xhr.status, errorMessage: errInfo + '(error)' });
    };
    xhr.ontimeout = function () {
        callback({ status: xhr.status, errorMessage: errInfo + '(time out)' });
    };
    xhr.send(null);
};

cc.loader.addDownloadHandlers({ "json": funcJson });

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=utils.js.map
        