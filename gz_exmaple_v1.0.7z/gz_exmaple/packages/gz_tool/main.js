'use strict';
		
function onBeforeBuildFinish (options, callback) {
	
	
    Editor.log('Building ' + options.platform + ' to ' + options.dest); // 你可以在控制台输出点什么
	Editor.Scene.callSceneScript('gz_tool', 'say-gzstart', options, function (err, val) {
			Editor.log(`say-gzstart rep:${val}`);
	});
    callback();
}

module.exports = {
  load () {
    // execute when package loaded
	Editor.Builder.on('before-change-files', onBeforeBuildFinish);
  },

  unload () {
    // execute when package unloaded
	Editor.Builder.removeListener('before-change-files', onBeforeBuildFinish);
  },

  // register your ipc messages here
  messages: {
    'open' () {
      // open entry panel registered in package.json
      Editor.Panel.open('gz_tool');
    },
    'say-hello' () {
      Editor.log('Hello World!');
      // send ipc message to panel
      //Editor.Ipc.sendToPanel('gz_tool', 'gz_tool:hello');
	  
	  
	  Editor.Scene.callSceneScript('gz_tool', 'say-gzfile', function (err, val) {
			Editor.log(`say-gzfile rep:${val}`);
		});
    },
    'clicked' () {

    }
  },
};