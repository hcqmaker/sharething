const path = require('path');
const fs = require('fs');
const zlib = require('zlib');

// 遍历目录
function findPaths(ph, list, ext, filters){
	var pa = fs.readdirSync(ph);
	pa.forEach(function(file,index){
		var info = fs.statSync(ph+"/"+file)
		if(info.isDirectory()){
			findPaths(ph+"/"+file, list, ext, filters);
		}else{
			
			if (path.extname(file) == ext){
				var onlyname = path.basename(file, ext);
				if (!filters || !filters[onlyname]){
					list.push(ph+"/"+file);
				}
			}
		}	
	})
}
		
module.exports = {
    
	'ouput_deepQuery':function(){
		Editor.assetdb.deepQuery(function (err, results) {
		  results.forEach(function (result) {
			// result.name
			// result.extname
			// result.uuid
			// result.type
			// result.isSubAsset
			// result.children - the array of children result
			Editor.log('===>> xx==>', result.name, result.type);
		  });
		});
		/*
		Editor.assetdb.queryAssets('db://assets/**\/*', 'texture', function (err, results) {
			results.forEach(function (result) {
				// result.url
				// result.path
				// result.uuid
				// result.type
			});
		});
		*/
	},
	'say-gzstart':function(event,options){
		// Editor.log("options", options);
		// 输出目录
		var dest = options.dest;
		var startScene = options.startScene;
		
		var buildResults = options.buildResults;
		var _buildAssets = buildResults._buildAssets;
		var _packedAssets = buildResults._packedAssets;
		
		// 遍历所有json文件
		var jsons = [];
		// 排除开始场景, 需要开始场景中加入json的加密加载方案,否则可能有问题
		var filters = {startScene:true};		
		
		findPaths(dest, jsons, '.json', filters);
		Editor.log("jsons", jsons);
		
		var sz = 1000;
		
		jsons.forEach(jsonPath=>{
			var states = fs.statSync(jsonPath);
			if (states.size > sz){
				var data = fs.readFileSync(jsonPath);
				var buff = zlib.gzipSync(data);
				fs.writeFileSync(jsonPath, buff);
			}
		});
	},
};