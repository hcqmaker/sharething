const path = require('path');
const fs = require('fs');
const zlib = require('zlib');

// 遍历目录
function findPaths(ph, list, ext, filters){
	var pa = fs.readdirSync(ph);
	pa.forEach(function(file,index){
		var info = fs.statSync(ph+"/"+file)
		if(info.isDirectory()){
			findPaths(ph+"/"+file, list, ext, filters);
		}else{
			
			if (!ext || path.extname(file) == ext){
				var onlyname = path.basename(file, ext);
				if (!filters || !filters[onlyname]){
					list.push(ph+"/"+file);
				}
			}
		}	
	})
}
		
module.exports = {
    
	'ouput_deepQuery':function(){
		Editor.assetdb.deepQuery(function (err, results) {
		  results.forEach(function (result) {
			// result.name
			// result.extname
			// result.uuid
			// result.type
			// result.isSubAsset
			// result.children - the array of children result
			Editor.log('===>> xx==>', result.name, result.type);
		  });
		});
		/*
		Editor.assetdb.queryAssets('db://assets/**\/*', 'texture', function (err, results) {
			results.forEach(function (result) {
				// result.url
				// result.path
				// result.uuid
				// result.type
			});
		});
		*/
	},
	'say-gzstart':function(event,options){
		// Editor.log("options", options);
		// 输出目录
		var dest = options.dest;
		var startScene = options.startScene;
		
		var buildResults = options.buildResults;
		var _buildAssets = buildResults._buildAssets;
		var _packedAssets = buildResults._packedAssets;
		
		// 遍历所有json文件
		var jsons = [];
		// 排除开始场景, 需要开始场景中加入json的加密加载方案,否则可能有问题
		// 这里这对wechat 中的开始的两个json配置文件先排除掉
		var filters = {'game':true,'project.config':true};//{startScene:true};
		
		findPaths(dest, jsons, '.json', filters);

		jsons.forEach(jsonPath=>{
			// 替换成gz文件
			var outpath = jsonPath.replace(".json", ".gz");
			var data = fs.readFileSync(jsonPath);
			var buff = zlib.gzipSync(data);
			fs.writeFileSync(outpath, buff);
		});
		
		jsons.forEach(jsonPath=>{
			fs.unlinkSync(jsonPath);
		});
		
		
		// 复制文件和处理头部 这里用于复制一些需要的文件和设置一些信息
		if (cc.sys.platform == cc.sys.WECHAT_GAME){
			/*
			var sdkpath = 'xxxx';
			var  cps = [];
			findPaths(sdkpath, cps);
			var outpath = dest+'/utils';
			if (!fs.existsSync(outpath)){
				fs.mkdirSync(outpath);
			}
			cps.forEach(fp=>{
				var fn = path.basename(fp);
				fs.writeFileSync(outpath + "/" + fn, fs.readFileSync(fp));
			});
			
			// 添加头部
			var gamefn = dest + '/game.js';
			var gamedt = 'require(\'utils/ald-game.js\')\n' + fs.readFileSync(gamefn, 'utf8');
			fs.writeFileSync(gamefn, gamedt);
			*/
		}
		
	},
};