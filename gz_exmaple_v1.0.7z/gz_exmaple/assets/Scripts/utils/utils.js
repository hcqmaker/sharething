"use strict";

var Uint8ArrayToString = function(uint8array){
    return new TextDecoder("utf-8").decode(uint8array);
}

//=============================================
var funcJsonGz =  function(item, callback) {
    // 根据不同情况进行判断处理否则问题多多
    var url = item.url;
    if (!CC_EDITOR && CC_BUILD && !CC_PREVIEW){
        url = url.replace(".json", ".gz");
    }
    var errInfo = 'Load binary data failed: ' + url + '';
    var xhr = cc.loader.getXMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = "arraybuffer";
    xhr.onload = function () {
        var arrayBuffer = xhr.response;
        if (arrayBuffer) {
            var result = new Uint8Array(arrayBuffer);

            let outString = "";
            let uerr = null;
            //===================================
            // 判断开头的处理 是否是压缩方式
            if (result[0] == 0x1f && result[1] == 0x8b){
                try {
                    outString = pako.inflate(result, { gzip: true, to: 'string'});
                } catch (error) {
                    cc.log(error);
                    uerr = error;
                }
            }else{
                outString = Uint8ArrayToString(result);
            }
            //===================================
            if (!uerr){
                callback(null, outString);
            }else{
                callback({status:-1, err:uerr,errorMessage:errInfo + " pako.inflate fail "});
            }
        }
        else {
            callback({status:xhr.status, errorMessage:errInfo + '(no response)'});
        }
    };
    xhr.onerror = function(){
        callback({status:xhr.status, errorMessage:errInfo + '(error)'});
    };
    xhr.ontimeout = function(){
        callback({status:xhr.status, errorMessage:errInfo + '(time out)'});
    };
    xhr.send(null);
}



cc.loader.addDownloadHandlers({"json":funcJsonGz});
cc.loader.addDownloadHandlers({"gz":funcJsonGz});