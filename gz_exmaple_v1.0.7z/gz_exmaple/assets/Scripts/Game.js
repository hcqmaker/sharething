
cc.Class({
    extends: cc.Component,

    properties: {

    },

    start () {
        cc.loader.loadRes("prefabs/node_01", (err, prefab)=>{
            if (err) {
                cc.error(err.message || err);
                return;
            }

            var n = cc.instantiate(prefab);
            this.node.addChild(n);

        });
    },

    // update (dt) {},
});
