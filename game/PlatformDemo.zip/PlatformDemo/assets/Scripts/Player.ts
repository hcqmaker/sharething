
const {ccclass, property} = cc._decorator;

@ccclass
export default class Player extends cc.Component {

    @property(cc.Node) colliderTag:cc.Node = null; // 标记是否碰撞
    @property(cc.Label) desc:cc.Label = null;   // 用于显示各种说明文字的

    @property(cc.Node)
    playerAvatar: cc.Node = null;

    @property(cc.Vec2)
    gravity:cc.Vec2 = cc.v2(0, -320);       // 设置重力加速度

    @property
    jumpTimeMax:number = 2;

    @property
    moveSpeed:number = 200;

    @property
    jumpUp:number = 300;

    touchingNumber: number = 0; // 标记碰撞和未知碰撞
    body:cc.RigidBody = null;

    playerAnime:cc.Animation = null;

    jumpTime:number = 0;
    bJump:boolean = false;
    bJumpDown:boolean = false;

    keyLeftDown:boolean = false;
    keyRightDown:boolean = false;
    keyAttackDown:boolean = false;

    directionX:number = 0;

    private descArr:Array<string> = [];
    

    onLoad () {

        this.touchingNumber = 0;

        // 物理步长，默认 FIXED_TIME_STEP 是 1/60
        cc.PhysicsManager.FIXED_TIME_STEP = 1/30;

        // 每次更新物理系统处理速度的迭代次数，默认为 10
        cc.PhysicsManager.VELOCITY_ITERATIONS = 8;

        // 每次更新物理系统处理位置的迭代次数，默认为 10
        cc.PhysicsManager.POSITION_ITERATIONS = 8;
        
        var manager = cc.director.getPhysicsManager();
        // 开启物理步长的设置
        manager.enabledAccumulator = true;
        manager.enabled = true; 
        manager.gravity = this.gravity;

        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyPressed, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyReleased, this);
    }

    start () {
        this.bJumpDown = false;
        this.bJump = false;

        this.jumpTime = this.jumpTimeMax;
        this.body = this.getComponent(cc.RigidBody);
        this.playerAnime = this.playerAvatar.getComponent(cc.Animation);
    }

    onKeyPressed (event:cc.Event.EventKeyboard) {
        let keyCode = event.keyCode;
        switch(keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                // if (!this.keyLeftDown  && this.onGround()){
                if (!this.keyLeftDown){
                    this.log("===keyLeftDown===>>>");
                    this.playerAvatar.scaleX = -1;
                    this.directionX = -1;
                    
                    this.keyLeftDown = true;
                    this.playRun();
                }
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                // if (!this.keyRightDown && this.onGround()){
                if (!this.keyRightDown){
                    this.log("===keyRightDown===>>>");
                    this.playerAvatar.scaleX = 1;
                    this.directionX = 1;
                    this.keyRightDown = true;
                    this.playRun();
                }
                break;
            case cc.macro.KEY.q:
                if (!this.keyAttackDown){
                    this.keyAttackDown = true;
                    this.playAttack();
                }
                break;
            case cc.macro.KEY.w:
            case cc.macro.KEY.up:
            case cc.macro.KEY.space:
                if (this.jumpTime < this.jumpTimeMax && !this.bJumpDown){
                    this.jumpTime++;
                    this.bJump = true;
                }
                break;
        }
    }
    
    onKeyReleased (event:cc.Event.EventKeyboard) {
        let keyCode = event.keyCode;
        switch(keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                this.keyLeftDown = false;
                this.checkKeyMove();
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                this.keyRightDown = false;
                this.checkKeyMove();
                break;
            case cc.macro.KEY.q:
                this.keyAttackDown = false;
                break;
            case cc.macro.KEY.w:
            case cc.macro.KEY.up:
            case cc.macro.KEY.space:
                this.bJumpDown = false;
                    break;
        }
    }

    checkKeyMove(){
        if (!this.keyRightDown && !this.keyLeftDown){
            if (this.onGround()){
                this.body.linearVelocity = cc.v2(0, 0);
                this.playIdle();
            }
            this.log("===checkKeyMove===>>>");
        }
    }

    
    onBeginContact (contact:cc.PhysicsContact,self:cc.PhysicsCollider, other:cc.PhysicsCollider) {
        this.colliderTag.color = cc.Color.RED;
        this.touchingNumber ++;

        let normal = contact.getWorldManifold().normal;
        this.log("=normal=>>" + normal.toString());
        // TODO 需要考虑在进行更多判断
        if (this.jumpTime > 0 && normal.y < -0.6){   // 是从上面向下碰到的
            this.jumpTime = 0;
            if (!this.keyLeftDown && !this.keyRightDown){
                let v = this.body.linearVelocity;
            v.x = 0;
            this.body.linearVelocity = v;
            }
        }
        if (!this.keyRightDown && !this.keyLeftDown){
            this.playIdle();
        }
        
    }
    
    onPreSolve (contact:cc.PhysicsContact,self:cc.PhysicsCollider, other:cc.PhysicsCollider) {
        //contact.getTangentSpeed
        
    }

    onEndContact (contact:cc.PhysicsContact,self:cc.PhysicsCollider, other:cc.PhysicsCollider) {
        this.touchingNumber --;
        if (this.touchingNumber === 0) {
            this.colliderTag.color = cc.Color.WHITE;
        }
    }
    //==============================================
    private onGround():boolean{
        return this.jumpTime <=0;
    }

    private log(s:string):void{
        this.descArr.push(s);
        let ds = this.descArr.reverse();
        let ss = ds.join("\n");
        this.desc.string = ss;

        if (this.descArr.length > 50){
            this.descArr.splice(1, 10);
        }
    }
    //===============================================
    private playIdle(){
        this.playerAnime.stop();
        this.playerAnime.play("AM_player_idle");
    }
    private playAttack(){
        this.playerAnime.play("AM_player_attack");
    }

    private playRun(){
        this.playerAnime.play("AM_player_run");
    }

    private playJumpUp(){
        this.playerAnime.play("AM_player_jumpup");
    }

    private playJumpFall(){
        this.playerAnime.play("AM_player_jumpfall");
    }

    onDestroy(){
        cc.director.getPhysicsManager().enabled = false;
    }

    update (dt) {
        if (this.bJump){
            this.bJump = false;
            let v = this.body.linearVelocity;
            v.y = this.jumpUp;
            this.body.linearVelocity = v;
        }

        if (this.keyLeftDown || this.keyRightDown){
            let scale = this.onGround() ? 1 : 0.5; 
            let v = this.body.linearVelocity;
            v.x = this.moveSpeed * this.directionX * scale;
            this.body.linearVelocity = v;
        }

        
        
    }
}
