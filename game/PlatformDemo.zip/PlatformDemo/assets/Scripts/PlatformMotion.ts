
const {ccclass, property} = cc._decorator;

@ccclass
export default class PlatformMotion extends cc.Component {

    @property speed:number = 10;    // 移动的速度
    @property distance = 200;       // 移动的距离
    @property leftright = true;     // 左右移动还是上下移动

    body: cc.RigidBody = null;

    _movedDistance:number = 0.0;
    _direction:number = 0;
    _movedDiff:number = 0;


    onLoad () {
        this._movedDistance = this.distance / 2;
        this._direction = 1;
        this._movedDiff = 0;
    }

    start () {
        this.body = this.getComponent(cc.RigidBody);
        this.updateVelocity();
    }

    updateVelocity(){
        var vspeed = this._direction * this.speed;

        let v = cc.v2(0, vspeed)
        if (this.leftright){
            v = cc.v2(vspeed, 0)
        }
        this.body.linearVelocity = v;
    }

    update (dt) {
        var d = this.speed * this._direction * dt;

        this._movedDistance += Math.abs(d);
        if (this._movedDistance > this.distance) {  // 切换方向
            d = this.distance - this._movedDistance;
            this._movedDistance = 0;
            this._direction *= -1;

            this.updateVelocity();
        }
    }
}
