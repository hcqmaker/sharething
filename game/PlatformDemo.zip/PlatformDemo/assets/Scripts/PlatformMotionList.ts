

// 处理多段移动等等的设置
// TODO

const {ccclass, property} = cc._decorator;

@ccclass
export default class PlatformMotion extends cc.Component {

    @property(cc.Label)
    label: cc.Label = null;

    @property
    text: string = 'hello';

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {

    }

    // update (dt) {}
}
